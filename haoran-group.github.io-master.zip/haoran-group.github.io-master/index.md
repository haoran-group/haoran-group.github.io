About

We are a research group in the Department of Physics, The Chinese University of Hong Konng. Our research focuses on topological physics of waves, including sound, microwave and light. We aim at both discovering new fundamental physics and developing new practical applications. 

